var datas = [
    {
        "src" : "/Js_08_Dom/06_exo_01/images/monstre1.jpg",
        "title" : "Boule verte",
        "alt" : "Monstre poilu vert"
    },
    {
        "src" : "/Js_08_Dom/06_exo_01/images/monstre2.jpg",
        "title" : "Tentaculos",
        "alt" : "Pieuvre bleue à rayures"
    },
    {
        "src" : "/Js_08_Dom/06_exo_01/images/monstre3.jpg",
        "title" : "Monstre à sucette",
        "alt" : "Monstre à sucette"
    },
    {
        "src" : "/Js_08_Dom/06_exo_01/images/monstre4.jpg",
        "title" : "Triglobuleux",
        "alt" : "Monstre à 3 zieux"
    },
    {
        "src" : "/Js_08_Dom/06_exo_01/images/monstre5.jpg",
        "title" : "Diablotin",
        "alt" : "Diable rouge"
    },
    {
        "src" : "/Js_08_Dom/06_exo_01/images/monstre6.jpg",
        "title" : "Chewbacca rose",
        "alt" : "Monstre poilu rose"
    }
];

let img = document.createElement("img");
    img.src = "/Js_08_Dom/06_exo_01/images/monstre1.jpg"
var div = document.getElementById("galerie");
    div.appendChild(img);
