const menuItems = [
    {
      name: "Accueil",
      url: 'https://google.com/',
      icons: './icons/home.svg'
    },
    {
      name: "Mon compte en banque",
      url: 'https://amazon.com/',
      icons: './icons/work.svg'
    },
    {
      name: "A propos de moi",
      url: 'https://vesass.github.io/',
      icons: './icons/about.svg'
    },
    {
      name: "Contact",
      url: 'https://triptyk.eu/',
      icons: './icons/contact.svg'
    },
  ]


//CECI EST UNE VERSION DE SINGE !!!!

  const markup = `
    <div id="container">
        <ul>
        <li>
        <a href="${menuItems[0].url}"><img>${menuItems[0].icons} </img> ${menuItems[0].name} </a>
        </li>
        </ul>
    </div>
    <div id="container">
        <ul>
        <li>
        <a href="${menuItems[1].url}"><img>${menuItems[1].icons} </img> ${menuItems[1].name} </a>
        </li>
        </ul>
    </div>
    <div id="container">
        <ul>
        <li>
        <a href="${menuItems[2].url}"><img>${menuItems[2].icons} </img> ${menuItems[2].name} </a>
        </li>
        </ul>
    </div>
    <div id="container">
        <ul>
        <li>
        <a href="${menuItems[3].url}"><img>${menuItems[3].icons} </img> ${menuItems[3].name} </a>
        </li>
        </ul>
    </div>
`;




document.getElementById("output").innerHTML = markup;